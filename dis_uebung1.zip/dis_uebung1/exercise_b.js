const { Client } = require("pg");

async function printTable(client, label) {
  const res = await client.query("SELECT * FROM students ORDER BY id;");
  console.log(`Table content (${label}):`);
  if (res.rows.length === 0) {
    console.log("No entries");
  } else {
    console.table(res.rows);
  }
}

async function main() {
  // i) Verbindung A öffnen
  const clientA = new Client({
    host: "localhost",
    database: "dis_uebung1",
    user: "postgres",
    password: "0307",
    port: 5432,
  });
  await clientA.connect();
  console.log("Connection A is open");

  // ii)
  await clientA.query(`
  CREATE TABLE students (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    grade INT
  );
`);

  await clientA.query(
    "INSERT INTO students (name, grade) VALUES ('Laura', 1);",
  );
  console.log("Table was created and Laura was inserted");

  // iii)
  const clientB = new Client({
    host: "localhost",
    database: "dis_uebung1",
    user: "postgres",
    password: "0307",
    port: 5432,
  });

  await clientB.connect();
  console.log("Connection B is open");

  // iv
  await clientA.query("BEGIN;");
  await clientB.query("BEGIN;");
  console.log("Transactions A and B started");

  // v
  await clientA.query("INSERT INTO students (name, grade) VALUES ('Alex', 2);");
  console.log("Connection A: Alex was inserted");

  // vi
  await clientB.query(
    "INSERT INTO students (name, grade) VALUES ('Bernd', 3);",
  );
  console.log("Connection B: Bernd was inserted");

  // vii
  await printTable(clientA, "Verbindung A");
  await printTable(clientB, "Verbindung B");

  // viii
  await clientA.query("COMMIT;");
  console.log("Connection A committed");
  await printTable(clientA, "Connection A after commit");

  await clientB.query("COMMIT;");
  console.log("Connection B committed");
  await printTable(clientB, "Connection B after commit");

  // ix
  const clientC = new Client({
    host: "localhost",
    database: "dis_uebung1",
    user: "postgres",
    password: "0307",
    port: 5432,
  });

  await clientC.connect();
  console.log("Connection C opened");
  await printTable(clientC, "Connection C");
  await clientC.end();

  // x
  await clientA.query("BEGIN;");
  await clientB.query("BEGIN;");
  console.log("New transactions started in A and B");

  // xi
  await clientA.query("UPDATE students SET grade = 10 WHERE name = 'Laura';");
  console.log("Connection A: Laura grade --> 10");

  await clientB.query("UPDATE students SET grade = 20 WHERE name = 'Laura';");
  console.log("Connection B: Laura grade --> 20");

  // xii
  let aSuccess = false;
  let bSuccess = false;
  try {
    await clientA.query("COMMIT;");
    console.log("Connection A committed");
    await printTable(clientA, "Connection A after commit");
    aSuccess = true;
  } catch (err) {
    console.log("Connection A commit failed:", err.message);
    await clientA.query("ROLLBACK;");
  }

  try {
    await clientB.query("COMMIT;");
    console.log("Connection B committed");
    await printTable(clientB, "Connection B after commit");
    bSuccess = true;
  } catch (err) {
    console.log("Connection B commit failed:", err.message);
    await clientB.query("ROLLBACK;");
  }

  // xiii
  if (aSuccess && bSuccess) {
    const clientC = new Client({
      host: "localhost",
      database: "dis_uebung1",
      user: "postgres",
      password: "0307",
      port: 5432,
    });
    await clientC.connect();
    console.log("Connection C opened");
    await printTable(clientC, "Connection C");
    await clientC.end();
  }
}

main().catch((err) => {
  console.error("Fehler:", err);
  process.exit(1);
});
