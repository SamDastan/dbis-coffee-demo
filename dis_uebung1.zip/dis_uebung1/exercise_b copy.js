const { Client } = require("pg");

const config = {
  host: "localhost",
  database: "dis_uebung1",
  user: "postgres",
  password: "0307",
  port: 5432,
};

async function printTable(client, label) {
  const res = await client.query("SELECT * FROM students ORDER BY id;");
  console.log(`Table content (${label}):`);
  if (res.rows.length === 0) {
    console.log("No entries");
  } else {
    console.table(res.rows);
  }
}

async function main() {
  // i) Verbindung A öffnen
  const clientA = new Client(config);
  await clientA.connect();
  console.log("✅ Verbindung A geöffnet");

  // ii) Tabelle erstellen und ersten Datensatz einfügen
  await clientA.query(`
    DROP TABLE IF EXISTS students;
    CREATE TABLE students (
      id   SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      grade INT
    );
  `);
  await clientA.query(
    "INSERT INTO students (name, grade) VALUES ('Alice', 1);",
  );
  console.log("✅ Tabelle erstellt und ersten Datensatz eingefügt (Alice, 1)");

  // iii) Verbindung B öffnen
  const clientB = new Client(config);
  await clientB.connect();
  console.log("✅ Verbindung B geöffnet");

  // iv) Transaktionen starten
  await clientA.query("BEGIN;");
  await clientB.query("BEGIN;");
  console.log("\n🔄 Transaktionen in A und B gestartet");

  // v) Verbindung A: neuen Datensatz einfügen
  await clientA.query("INSERT INTO students (name, grade) VALUES ('Bob', 2);");
  console.log("➕ Verbindung A: Bob (2) eingefügt");

  // vi) Verbindung B: anderen neuen Datensatz einfügen
  await clientB.query(
    "INSERT INTO students (name, grade) VALUES ('Charlie', 3);",
  );
  console.log("➕ Verbindung B: Charlie (3) eingefügt");

  // vii) Tabelleninhalt in beiden Verbindungen prüfen
  await printTable(clientA, "Verbindung A vor Commit");
  await printTable(clientB, "Verbindung B vor Commit");

  // viii) Beide Transaktionen committen
  await clientA.query("COMMIT;");
  console.log("\n✅ Verbindung A committed");
  await printTable(clientA, "Verbindung A nach Commit");

  await clientB.query("COMMIT;");
  console.log("✅ Verbindung B committed");
  await printTable(clientB, "Verbindung B nach Commit");

  // ix) Dritte Verbindung öffnen und Inhalt prüfen
  const clientC = new Client(config);
  await clientC.connect();
  await printTable(clientC, "Verbindung C (neu)");
  await clientC.end();

  // x) Neue Transaktionen starten
  await clientA.query("BEGIN;");
  await clientB.query("BEGIN;");
  console.log("\n🔄 Neue Transaktionen in A und B gestartet");

  // xi) Beide updaten denselben Datensatz (Alice) mit verschiedenen Werten
  await clientA.query("UPDATE students SET grade = 10 WHERE name = 'Alice';");
  console.log("✏️  Verbindung A: Alice grade → 10");

  console.log("⏳ Verbindung B versucht Alice auf grade = 20 zu setzen...");
  try {
    // clientB wird hier blockieren bis A committed oder ein Timeout auftritt
    await clientB.query("UPDATE students SET grade = 20 WHERE name = 'Alice';");
    console.log("✏️  Verbindung B: Alice grade → 20");
  } catch (err) {
    console.log("❌ Verbindung B: Fehler beim UPDATE:", err.message);
  }

  // xii) Beide committen
  try {
    await clientA.query("COMMIT;");
    console.log("✅ Verbindung A committed");
    await printTable(clientA, "Verbindung A nach UPDATE-Commit");
  } catch (err) {
    console.log("❌ Verbindung A Commit fehlgeschlagen:", err.message);
    await clientA.query("ROLLBACK;");
  }

  try {
    await clientB.query("COMMIT;");
    console.log("✅ Verbindung B committed");
    await printTable(clientB, "Verbindung B nach UPDATE-Commit");
  } catch (err) {
    console.log("❌ Verbindung B Commit fehlgeschlagen:", err.message);
    await clientB.query("ROLLBACK;");
  }

  // xiii) Dritte Verbindung: Endergebnis prüfen
  const clientD = new Client(config);
  await clientD.connect();
  await printTable(clientD, "Verbindung C (neu, nach allen UPDATEs)");
  await clientD.end();

  // Verbindungen schließen
  await clientA.end();
  await clientB.end();
  console.log("\n🏁 Fertig!");
}

main().catch((err) => {
  console.error("Fehler:", err);
  process.exit(1);
});
